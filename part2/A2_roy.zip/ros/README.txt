To run Gazebo:
> roslaunch exercises gazebo_simple.launch

To run potential field navigation:
> roslaunch exercises potential_field_navigation.launch

To run RRT navigation:
> roslaunch exercises rrt_navigation.launch

To run RViz:
> roslaunch exercises rviz.launch

To run SLAM:
> roslaunch exercises slam.launch